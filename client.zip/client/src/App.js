import './App.css';
import Register from "./components/Login_register/Register";
import Login from './components/Login_register/Login';
import Home from './components/Home/Home';
import DeleteContact from './components/Home/DeleteContact';
import SearchContact from './components/Home/SearchContact';
import UpdateContact from './components/Home/UpdateContact';
import AddContact from './components/Home/AddContact';
import ViewContact from './components/Home/ViewContact';
import UpdateContactView from './components/Home/UpdateContactView';
import { BrowserRouter,Routes,Route }from 'react-router-dom';
function App() {

  
  return (
    <div className="App">
     {/* <Header/>
     <Register /> */}
     <BrowserRouter>
      <Routes>
       
        <Route  path='/' element={< Login />}></Route>
        <Route  path='/register' element={ <Register /> } > </Route>
        <Route  path='/home' element={< Home />}></Route>
        <Route  path='/deletecontact' element={< DeleteContact />}></Route>
        <Route  path='/searchcontact' element={< SearchContact />}></Route>
        <Route  path='/updatecontact' element={< UpdateContact />}></Route>
        <Route  path='/addcontact' element={< AddContact />}></Route>
        <Route  path='/viewcontact' element={< ViewContact />}></Route>
        <Route  path='/UpdateContactView/:id' element={< UpdateContactView />}></Route>
       
        
        
        
     </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
