import { PersonCircle } from 'react-bootstrap-icons';
import { Link,useNavigate  } from 'react-router-dom';
import { useState } from 'react';
import  { getUser } from '../../services/api';
import  { Logininputfield } from './Inputfield';
function Login() {
    const initial={
        name:'',
        password:''
        }
     
    const[user,setUser]=useState(initial);
    const navigate= useNavigate();
    
    const onValueChange = (e) =>{
        setUser({...user,[e.target.name]:e.target.value})
      };
    
    const handleSubmit = async (e) =>
         {
           e.preventDefault();
           console.log("user add", user);
           Validite(user);
           let result = await getUser(user);
           console.log(result);
           if(result.data.message)
           {
            //loalhost in data store
            alert(result.data.message);
            localStorage.setItem("Username", user.name);
            navigate('/home');
           }
           else{
            console.log("result",result);
            alert(result.data.error);
           }
           
        }     
   function Validite(value) {
      if((value.name).length <= 0) 
      { 
        alert("name must be required")
      }
      if((value.password).length <= 0) 
      {
         alert("password must be required")
      }
         if((value.password).length < 8)  
      { 
       alert("password must be 8 digit ")          
      }
   }
  return (
    <>     
    <div className="container mt-5">
    
    <PersonCircle size={100} className="mt-4"/>
    <h4 className='mt-2'>Login Form</h4>
    <form className="mt-2" onSubmit={handleSubmit}>             
               { Logininputfield.map((inputfields, index) => {
                    return (
                            <div key={index} > 
                                <div className="row mt-3">
                                    <div className="col-lg-12"><label name= {inputfields.fieldname}>  {inputfields.fieldname} </label></div>
                                </div>
                                <div className="row">
                                  <div className="col-lg-12"> 
                                    <input type="text" 
                                        name= {inputfields.fieldvalue} 
                                        placeholder=  {inputfields.fieldname}
                                        onChange={(e)=>onValueChange(e)} /> 
                                </div>
                                </div>
                            </div>
                    );
                })}  
           
                
        <div className="row mt-4">
            <div className="col-lg-4"></div>
            <div className="col-lg-4"> <input type="submit" /></div>
            <div className="col-lg-4"></div>
        </div>
    </form>
    <div className='row mt-2'>
            <div className="col-lg-4"></div>
            <div className="col-lg-4"> <Link to ="/register">Click here to Registration </Link></div>
            <div className="col-lg-4"></div>
    </div>
    </div>
  

    

    </>
  )
}

export default Login


/*
required modules

react-bootstrap-icons
react-bootstrap
*/

/*
1 login form created 
2 make dynamic 
3 all value get in one object 
4 localhost in value save after submitted
5 field in validation set 
*/