
import Header from "../Common_component/Header";
import Footer from "../Common_component/Footer";
import { useState } from 'react';
import  { SearchContactUser } from '../../services/api';


function SearchContact() {
  const initial={
    name:'',
    }
 
const[user,setUser]=useState(initial);
const [show,setShow]=useState('');
  const onValueChange = (e) =>{
    setUser({...user,[e.target.name]:e.target.value})
  };
  const handleSubmit = async (e) =>
  {
    e.preventDefault();
    console.log("user add", user);
   
    let result = await SearchContactUser(user);
    console.log(result);
    if(result.data.message)
    {
     //loalhost in data store
     alert(result.data.message);
     setShow(result.data);
     
    
    
    }
    else{
     console.log("result",result);
     alert("No contact found");
    }
    
 }    
  return (
    <>
        <Header/>
        <div>
        <form  onSubmit={handleSubmit}>
        <input type="text" 
               name= "name" 
               placeholder=  "search contact name"
               onChange={(e)=>onValueChange(e)} /> 
        <input type="submit" />
        </form>
        
       { show && show.data ? 
         <div> { show.data.map((value,index) =>       
               { 
                return( <p key={index}>{value.name}{value.conatctNumber} </p> ) 
               })}
          </div>
          :"no data found"}

        </div>
        <Footer/>
    </>
  )
}

export default SearchContact