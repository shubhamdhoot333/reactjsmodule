import React from 'react'
import Header from "../Common_component/Header"
import Footer from "../Common_component/Footer";
import { useEffect, useState } from 'react';
import { viewContact }from  '../../services/api';
import { Link } from "react-router-dom";
function UpdateContact() {
    const [contact,setContact]=useState("")
    useEffect(()=>{
      getAllOrder();
    },[])
   
    const getAllOrder = async () => {
      const order_data = await viewContact();
      setContact(order_data.data.data);
     
  
    };
  return (
    <div>
        <Header/>
        <h4>Update Contact</h4>

        { contact ? 
            (contact.map((value,index)=>{return(
            <p key={index}>
            {value.name}
            {value.conatctNumber}
            <button type="button"  className="btn btn-danger"> 
            <Link to={`/UpdateContactView/${value._id}`}> 
                update
            </Link> 
            </button>
            </p> 
           
        
            )} ) )
           :
           "no data found"}
        <Footer/>

    </div>
  )
}

export default UpdateContact