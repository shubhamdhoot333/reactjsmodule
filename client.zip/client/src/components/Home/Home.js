
import Header from "../Common_component/Header";
import Footer from "../Common_component/Footer";



function Home() {
  return (
    <>
        <Header/>
        Home
        <Footer/>
    </>
  )
}

export default Home