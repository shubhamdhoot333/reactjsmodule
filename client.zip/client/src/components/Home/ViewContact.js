import React,{ useEffect, useState } from 'react';
import Header from "../Common_component/Header";
import Footer from "../Common_component/Footer";
import { viewContact }from  '../../services/api';


function ViewContact() {
  const [contact,setContact]=useState("")
  useEffect(()=>{
    getAllOrder();
  },[])
 
  const getAllOrder = async () => {
    const order_data = await viewContact();
    setContact(order_data.data.data);
    console.log(order_data.data.data);

  };

  return (
    <div>
       <Header/>
       
          { contact ? 
            (contact.map((value,index)=>{return(
            <p key={index}>
            {value.name}
            {value.conatctNumber}</p> 
           
        
            )} ) )
           :
           "no data found"}
      
      <Footer/>
      </div>
  )
}

export default ViewContact



