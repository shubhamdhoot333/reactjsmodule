import axios from 'axios';
//register component 
export const addUser = async (data) =>{
    try{
         
        const result= await axios.post("http://localhost:8000/register",data);
        //   console.log(result);
          return result;
    
        }
        catch(error){
            console.log(error.message);
        }
    };
//login component 
export const getUser = async (data) =>{
    try{
         
        const result= await axios.post("http://localhost:8000/login",data);
        // console.log(result)
        return result;
    
        }
        catch(error){
            console.log(error.message);
        }
    };   

  //add contact number 
export const addContactUser = async (data) =>{
    try{
         
        const result= await axios.post("http://localhost:8000/addcontactuser",data);
        // console.log(result)
        return result;
    
        }
        catch(error){
            console.log(error.message);
        }
    }; 
  //view contact number 
export const viewContact = async () =>{
    try{
         
        const result= await axios.get("http://localhost:8000/viewContact");
        // console.log(result)
        return result;
    
        }
        catch(error){
            console.log(error.message);
        }
    };
 //delete contact
   
export const deleteContact = async (data) =>{
    try{
         
        const result= await axios.post("http://localhost:8000/deleteContact",data);
        // console.log(result)
        return result;
    
        }
        catch(error){
            console.log(error.message);
        }
    };           
 //search contact 
  export const SearchContactUser = async (data) =>{
    try{
        
        const result= await axios.post("http://localhost:8000/SearchContactUser",data);
        // console.log(result)
        return result;
    
        }
        catch(error){
            console.log(error.message);
        }
    };   
    
 //getContactDetails
 export const getContactDetails = async (data) =>{
    try{
        
        const result= await axios.post("http://localhost:8000/getContactDetails",data);
       
        return result;
    
        }
        catch(error){
            console.log(error.message);
        }
    };  
 // //getContactDetails
 export const updateContactdata = async (data) =>{
    try{
        
        const result= await axios.post("http://localhost:8000/updateContactdata",data);
       
        return result;
    
        }
        catch(error){
            console.log(error.message);
        }
    };     